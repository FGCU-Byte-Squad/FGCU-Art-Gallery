import { useState } from "react";
import { LandingPage } from "./components/LandingPage";
import { GalleryView } from "./components/GalleryView";
import { AdminUpload } from "./components/AdminUpload";

type View = "landing" | "gallery" | "admin";

export default function App() {
  const [currentView, setCurrentView] = useState<View>("landing");
  const [searchQuery, setSearchQuery] = useState<string | undefined>(undefined);

  const navigateToGallery = (query?: string) => {
    setSearchQuery(query);
    setCurrentView("gallery");
  };

  const navigateToHome = () => {
    setSearchQuery(undefined);
    setCurrentView("landing");
  };

  const navigateToAdmin = () => {
    setCurrentView("admin");
  };

  if (currentView === "landing") {
    return <LandingPage onNavigateToGallery={navigateToGallery} onNavigateToAdmin={navigateToAdmin} />;
  }

  if (currentView === "admin") {
    return <AdminUpload onNavigateToHome={navigateToHome} />;
  }

  return (
    <GalleryView
      initialSearchQuery={searchQuery}
      onNavigateToHome={navigateToHome}
    />
  );
}
