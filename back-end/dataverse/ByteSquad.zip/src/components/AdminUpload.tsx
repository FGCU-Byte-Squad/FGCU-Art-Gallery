import { useState } from "react";
import { ArrowLeft, Upload, Plus, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Separator } from "./ui/separator";

interface AdminUploadProps {
  onNavigateToHome: () => void;
}

export function AdminUpload({ onNavigateToHome }: AdminUploadProps) {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  
  // Citation Metadata fields
  const [persistentId, setPersistentId] = useState("");
  const [publicationDate, setPublicationDate] = useState("");
  const [title, setTitle] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [authorAffiliation, setAuthorAffiliation] = useState("");
  const [authorIdentifierScheme, setAuthorIdentifierScheme] = useState("");
  const [authorIdentifier, setAuthorIdentifier] = useState("");
  const [pointOfContact, setPointOfContact] = useState("");
  const [pointOfContactEmail, setPointOfContactEmail] = useState("");
  const [description, setDescription] = useState("");
  const [subjects, setSubjects] = useState<string[]>([""]);
  const [keywords, setKeywords] = useState<string[]>([""]);
  
  // Art Metadata fields
  const [accessionNumber, setAccessionNumber] = useState("");
  const [artist, setArtist] = useState("");
  const [artistNationality, setArtistNationality] = useState("");
  const [centuryCreated, setCenturyCreated] = useState("");
  const [dateCreated, setDateCreated] = useState("");
  const [geographicLocation, setGeographicLocation] = useState("");
  const [artType, setArtType] = useState("");
  const [dimensions, setDimensions] = useState("");
  const [medium, setMedium] = useState("");
  const [printmaking, setPrintmaking] = useState("");
  const [printEditionNumber, setPrintEditionNumber] = useState("");
  const [artStyle, setArtStyle] = useState("");
  const [collection, setCollection] = useState("");
  const [creditLine, setCreditLine] = useState("");

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real implementation, this would upload to the Dataverse API
    const formData = {
      image: imageFile,
      citation: {
        persistentId,
        publicationDate,
        title,
        authorName,
        authorAffiliation,
        authorIdentifierScheme,
        authorIdentifier,
        pointOfContact,
        pointOfContactEmail,
        description,
        subjects: subjects.filter(s => s.trim()),
        keywords: keywords.filter(k => k.trim()),
      },
      art: {
        accessionNumber,
        artist,
        artistNationality,
        centuryCreated,
        dateCreated,
        geographicLocation,
        artType,
        dimensions,
        medium,
        printmaking,
        printEditionNumber,
        artStyle,
        collection,
        creditLine,
      }
    };

    console.log("Form submitted:", formData);
    alert("Upload functionality would connect to FGCU Dataverse API in production. See console for form data.");
  };

  const addSubject = () => setSubjects([...subjects, ""]);
  const removeSubject = (index: number) => setSubjects(subjects.filter((_, i) => i !== index));
  const updateSubject = (index: number, value: string) => {
    const newSubjects = [...subjects];
    newSubjects[index] = value;
    setSubjects(newSubjects);
  };

  const addKeyword = () => setKeywords([...keywords, ""]);
  const removeKeyword = (index: number) => setKeywords(keywords.filter((_, i) => i !== index));
  const updateKeyword = (index: number, value: string) => {
    const newKeywords = [...keywords];
    newKeywords[index] = value;
    setKeywords(newKeywords);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-border bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center gap-4">
            <img
              src="https://fgcucdn.fgcu.edu/advancement/universitymarketing/images/fgcu-logo-250h.jpg"
              alt="FGCU Logo"
              className="h-12 w-auto object-contain"
            />
            <div className="flex gap-2">
              <div className="w-1 h-12 bg-[#0067B1]" />
              <div className="w-1 h-12 bg-[#007749]" />
            </div>
            <div>
              <h1 className="tracking-tight">Admin Upload</h1>
              <p className="text-muted-foreground mt-1">
                Add new artwork to the FGCU Dataverse
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={onNavigateToHome}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Image Upload Section */}
          <div className="space-y-4">
            <h2 className="text-[#0067B1]">Artwork Image</h2>
            <div className="border-2 border-dashed border-border rounded-lg p-8">
              {imagePreview ? (
                <div className="space-y-4">
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="max-h-96 mx-auto object-contain"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setImageFile(null);
                      setImagePreview("");
                    }}
                    className="w-full"
                  >
                    Remove Image
                  </Button>
                </div>
              ) : (
                <div className="text-center">
                  <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <Label htmlFor="image-upload" className="cursor-pointer">
                    <span className="text-[#0067B1] hover:underline">Click to upload</span>
                    {" or drag and drop"}
                  </Label>
                  <Input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Citation Metadata Section */}
          <div className="space-y-6">
            <h2 className="text-[#0067B1]">Citation Metadata</h2>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="persistentId">Persistent Identifier</Label>
                <Input
                  id="persistentId"
                  value={persistentId}
                  onChange={(e) => setPersistentId(e.target.value)}
                  placeholder="doi:10.xxxx/xxxxx"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="publicationDate">Publication Date</Label>
                <Input
                  id="publicationDate"
                  type="date"
                  value={publicationDate}
                  onChange={(e) => setPublicationDate(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter artwork title"
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="authorName">Author Name</Label>
                <Input
                  id="authorName"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  placeholder="Full name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="authorAffiliation">Author Affiliation</Label>
                <Input
                  id="authorAffiliation"
                  value={authorAffiliation}
                  onChange={(e) => setAuthorAffiliation(e.target.value)}
                  placeholder="Institution or organization"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="authorIdentifierScheme">Author Identifier Scheme</Label>
                <Input
                  id="authorIdentifierScheme"
                  value={authorIdentifierScheme}
                  onChange={(e) => setAuthorIdentifierScheme(e.target.value)}
                  placeholder="e.g., ORCID"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="authorIdentifier">Author Identifier</Label>
                <Input
                  id="authorIdentifier"
                  value={authorIdentifier}
                  onChange={(e) => setAuthorIdentifier(e.target.value)}
                  placeholder="Identifier value"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pointOfContact">Point of Contact</Label>
                <Input
                  id="pointOfContact"
                  value={pointOfContact}
                  onChange={(e) => setPointOfContact(e.target.value)}
                  placeholder="Contact person name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pointOfContactEmail">Point of Contact Email</Label>
                <Input
                  id="pointOfContactEmail"
                  type="email"
                  value={pointOfContactEmail}
                  onChange={(e) => setPointOfContactEmail(e.target.value)}
                  placeholder="contact@fgcu.edu"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the artwork"
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Subjects</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addSubject}
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Subject
                </Button>
              </div>
              {subjects.map((subject, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={subject}
                    onChange={(e) => updateSubject(index, e.target.value)}
                    placeholder="Enter subject"
                  />
                  {subjects.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => removeSubject(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Keywords</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addKeyword}
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Add Keyword
                </Button>
              </div>
              {keywords.map((keyword, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={keyword}
                    onChange={(e) => updateKeyword(index, e.target.value)}
                    placeholder="Enter keyword"
                  />
                  {keywords.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => removeKeyword(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Art Metadata Section */}
          <div className="space-y-6">
            <h2 className="text-[#007749]">Art Metadata</h2>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="accessionNumber">Accession Number</Label>
                <Input
                  id="accessionNumber"
                  value={accessionNumber}
                  onChange={(e) => setAccessionNumber(e.target.value)}
                  placeholder="Catalog number"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="artist">Artist</Label>
                <Input
                  id="artist"
                  value={artist}
                  onChange={(e) => setArtist(e.target.value)}
                  placeholder="Artist name"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="artistNationality">Artist Nationality</Label>
                <Input
                  id="artistNationality"
                  value={artistNationality}
                  onChange={(e) => setArtistNationality(e.target.value)}
                  placeholder="e.g., American"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="centuryCreated">Century Created</Label>
                <Input
                  id="centuryCreated"
                  value={centuryCreated}
                  onChange={(e) => setCenturyCreated(e.target.value)}
                  placeholder="e.g., 21st Century"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dateCreated">Date Created</Label>
                <Input
                  id="dateCreated"
                  value={dateCreated}
                  onChange={(e) => setDateCreated(e.target.value)}
                  placeholder="Year or date"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="geographicLocation">Geographic Location</Label>
                <Input
                  id="geographicLocation"
                  value={geographicLocation}
                  onChange={(e) => setGeographicLocation(e.target.value)}
                  placeholder="Location depicted or created"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="artType">Art Type</Label>
                <Input
                  id="artType"
                  value={artType}
                  onChange={(e) => setArtType(e.target.value)}
                  placeholder="e.g., Painting, Sculpture"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dimensions">Dimensions</Label>
                <Input
                  id="dimensions"
                  value={dimensions}
                  onChange={(e) => setDimensions(e.target.value)}
                  placeholder="e.g., 24 x 36 inches"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="medium">Medium</Label>
                <Input
                  id="medium"
                  value={medium}
                  onChange={(e) => setMedium(e.target.value)}
                  placeholder="e.g., Oil on canvas"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="artStyle">Art Style</Label>
                <Input
                  id="artStyle"
                  value={artStyle}
                  onChange={(e) => setArtStyle(e.target.value)}
                  placeholder="e.g., Impressionism"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="printmaking">Printmaking</Label>
                <Input
                  id="printmaking"
                  value={printmaking}
                  onChange={(e) => setPrintmaking(e.target.value)}
                  placeholder="Printmaking technique"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="printEditionNumber">Print Edition Number</Label>
                <Input
                  id="printEditionNumber"
                  value={printEditionNumber}
                  onChange={(e) => setPrintEditionNumber(e.target.value)}
                  placeholder="e.g., 5/100"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="collection">Collection</Label>
              <Input
                id="collection"
                value={collection}
                onChange={(e) => setCollection(e.target.value)}
                placeholder="e.g., FGCU Art Galleries Permanent Collection"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="creditLine">Credit Line</Label>
              <Textarea
                id="creditLine"
                value={creditLine}
                onChange={(e) => setCreditLine(e.target.value)}
                placeholder="Credit line or acknowledgment"
                rows={2}
              />
            </div>
          </div>

          <Separator />

          {/* Submit Button */}
          <div className="flex gap-4">
            <Button
              type="submit"
              className="flex-1 bg-[#0067B1] hover:bg-[#0067B1]/90"
            >
              Upload to Dataverse
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onNavigateToHome}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>

          <p className="text-sm text-muted-foreground text-center">
            * This form would upload to FGCU Dataverse API in production. Currently for demonstration purposes.
          </p>
        </form>
      </main>
    </div>
  );
}
