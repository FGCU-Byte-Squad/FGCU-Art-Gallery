
  # Byte Squad

  This is a code bundle for Byte Squad. The original project is available at https://www.figma.com/design/aLWeIZi2w8Si38vMzGeinv/Byte-Squad.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  